package com.example.course_work.Service;


import com.example.course_work.Repository.Repository;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.List;

@Stateless
public class Service {
    @EJB
    private Repository repository;

    public List<String> getAllItems() throws SQLException, ClassNotFoundException {
        return repository.getAllItems();
    }
    public List<String> getAllICustomerName() throws SQLException, ClassNotFoundException {
        return repository.getAllCustomerName();
    }
    public List<String> getAllOrders() throws SQLException, ClassNotFoundException {
        return repository.getAllOrders();
    }

    public Response createCustomer(int id, String name, String surname) throws SQLException, ClassNotFoundException {
        if (repository.createCustomer(id,name,surname) == 1) return Response.ok().build();
        return Response.notModified().build();
    }

    public Response createOrder(int id, int items_id, int customer_id, int cost) throws SQLException, ClassNotFoundException {
        if (repository.createOrder(id,items_id,customer_id,cost) == 1) return Response.ok().build();
        return Response.notModified().build();
    }

    public Response deleteCustomer(int id) throws SQLException, ClassNotFoundException {
        return  repository.deleteCustomer(id);
    }
    public Response updateCustomerName(String name, int id) throws SQLException, ClassNotFoundException {
        return  repository.updateCustomerName(name,id);
    }
}