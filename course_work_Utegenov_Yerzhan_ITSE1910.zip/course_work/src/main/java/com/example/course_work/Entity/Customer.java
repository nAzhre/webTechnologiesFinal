package com.example.course_work.Entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@Table(name = "customer")
public class Customer {
    @Id
    private int id;
    private String name;
    private String surname;

}

