package com.example.course_work.Repository;

import java.util.ArrayList;
import java.util.List;

public class CreateDatabase {
    public static String createDatabaseSQL() {
        String array = "";
        //array = "DROP TABLE IF EXISTS demo; CREATE TABLE demo (ID integer primary key, Name varchar(200), Surname varchar(200) );";
        array += "DROP TABLE IF EXISTS items; CREATE TABLE  items (id serial primary key,name varchar(255),price integer,amount integer);";
        array += "DROP TABLE IF EXISTS orders; CREATE TABLE orders (id serial primary key,customer_id  integer,items_id integer, cost integer);";
        array += ("DROP TABLE IF EXISTS customer; CREATE TABLE customer (id serial primary key,name varchar(20), surname varchar(200)");
        return array;
    }

    public static List<String> loadData() {
        List<String> array = new ArrayList<>();
        array.add("insert into items values(2,'Samsung pro', 250000, 100);");
        array.add("insert into items values(3,'LG 88', 100000, 200);");

        return array;
    }
}
