package com.example.course_work.Resource;

import com.example.course_work.Aop.SupervisorBeforeAdvice;
import com.example.course_work.Service.Service;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.interceptor.Interceptors;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.List;

@Path("/hello-world")
public class Resource {
    @EJB
    Service service;

    @GET
    @Produces("application/json")
    public String hello() {
        return "Hello!";
    }

    @GET
    @Path("/getAllItems")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> getAllItems()throws SQLException, ClassNotFoundException {
        return service.getAllItems();
    }

    @GET
    @Path("/getAllCustomer")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> getAllCustomerName()throws SQLException, ClassNotFoundException {
        return service.getAllICustomerName();
    }

    @GET
    @Path("/getAllOrders")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> getAllOrders()throws SQLException, ClassNotFoundException {
        return service.getAllOrders();
    }

    @POST
    @Path("/createClient")
    @Produces("application/json")
    @Interceptors(SupervisorBeforeAdvice.class)
    @PermitAll
    @ApiOperation(value = "createCustomer")
    @ApiResponses({
            @ApiResponse(code=200, message="Success")
    })
    public Response createCustomer(
            @NotNull @QueryParam("hist_id") int id,
            @NotNull @QueryParam("name") String name,
            @NotNull @QueryParam("surname") String surname
    ) throws SQLException, ClassNotFoundException {
        return service.createCustomer(id, name, surname);
    }

    @POST
    @Path("/createOrder")
    @Produces("application/json")
    @PermitAll
    @ApiOperation(value = "createOrder")
    @ApiResponses({
            @ApiResponse(code=200, message="Success")
    })
    public Response createOrder(
            @NotNull @QueryParam("id") int id,
            @NotNull @QueryParam("items_id") int items_id,
            @NotNull @QueryParam("customer_id") int customer_id,
            @NotNull @QueryParam("cost") int cost
    ) throws SQLException, ClassNotFoundException {
        return service.createOrder(id,items_id, customer_id, cost);
    }

    @DELETE
    @Path("/deleteCustomerByID/{id}")
    @ApiOperation(value = "delete customer by id")
    @ApiResponses({
            @ApiResponse(code=200, message="Success delete")
    })
    @Produces("application/json")
    @RolesAllowed("ADMIN")
    public Response deleteCustomerByID(@NotNull @PathParam("id") int id) throws SQLException, ClassNotFoundException {
        return service.deleteCustomer(id);
    }

    @PUT
    @Path("/updateCustomerName/{id}/{newName}")
    @ApiOperation(value = "update customer name by id")
    @ApiResponses({
            @ApiResponse(code=200, message="Success")
    })
    @Consumes(MediaType.APPLICATION_JSON)
    @PermitAll
    @Interceptors(SupervisorBeforeAdvice.class)
    public Response updateCustomerName(
            @NotNull @PathParam("id") int id_user,
            @NotNull @PathParam("newName") String newName) throws SQLException, ClassNotFoundException {
        return service.updateCustomerName(newName, id_user);
    }

//    @GET
//    @Path("/getAllPersons")
//    @Produces(MediaType.APPLICATION_JSON)
//    public List<Items> getAllPerson(Items items) throws SQLException, ClassNotFoundException {
//        return Repository.getAllPersons();
//    }
//
//    @PUT
//    @Path("/updateItemsById")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String updateItemsById(Items items)throws SQLException, ClassNotFoundException {
//        service.updateItemsById(items);
//        return "Product info with this id was updated";
//    }
//
//    @POST
//    @Path("/addItems")
//    @Produces(MediaType.APPLICATION_JSON)
//    @Consumes(MediaType.APPLICATION_JSON)
//    public String addItems(@Valid Items items)throws SQLException, ClassNotFoundException {
//        service.addItems(items);
//        return "Product added";
//    }
//
//    @DELETE
//    @Path("/deleteItemsById")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String deleteItemsById(Items items)throws SQLException, ClassNotFoundException {
//        service.deleteItemsById(items);
//        return "Product info with this id was deleted";
//    }

}
