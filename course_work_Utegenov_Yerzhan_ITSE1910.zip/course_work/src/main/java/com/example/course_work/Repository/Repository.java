package com.example.course_work.Repository;

import com.example.course_work.Entity.Items;

import javax.annotation.Resource;
import javax.ejb.Stateful;
import javax.jms.Queue;
import javax.persistence.EntityExistsException;
import javax.transaction.Transactional;
import javax.validation.constraints.NotNull;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Stateful
public class Repository {

//    @Resource(name = "ClientMessageQueue")
//    private Queue ClientMessageQueue;
//
//    @Resource(name = "DriverMessageQueue")
//    private Queue DriverMessageQueue;
//
//    @Resource(name = "Notification")
//    private Queue Notification;

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/course_work";

    //  Database credentials
    private static final String USER = "postgres";
    private static final String PASS = "eroxadiana8899";

    private final Connection conn = null;
    private Statement stmt = null;

    public Repository() throws SQLException {
        // STEP 1: Register JDBC driver

        System.out.println("Start");
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("PostgreSQL JDBC Driver is not found. Include it in your library path ");
            e.printStackTrace();
            return;
        }
        // STEP 2: Open a connection
        System.out.println("Connecting to a selected database...");
        Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        // conn.setAutoCommit(false);
        System.out.println("Connected database successfully...");

        // STEP 3: Execute a query
        this.stmt = conn.createStatement();
        stmt.executeUpdate(CreateDatabase.createDatabaseSQL());
        CreateDatabase.loadData().forEach(sql -> {
            try {
                stmt.executeUpdate(sql);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

    }

    public List<String> getAllItems() throws SQLException {
        String sql = "select * from items";
        ResultSet rs = stmt.executeQuery(sql);
        List<String> lnames = new ArrayList<>();
        while (rs.next()) {
            int id = rs.getInt("id");
            String first = rs.getString("car_number");
            lnames.add(first);
        }
        return lnames;
    }

    @Transactional(rollbackOn = SQLException.class,
            dontRollbackOn = EntityExistsException.class)
    public List<String> getAllCustomerName() throws SQLException, ClassNotFoundException {
        String sql = "select * from customer";

        System.out.println("\n===========================\n");
        System.out.println("Creating savepoint...");
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery(sql);
            // conn.commit();
        } catch (SQLException e) {
            System.out.println("SQLException. Executing rollback to savepoint...");
        }
        List<String> customer = new ArrayList<>();
        while (true) {
            assert rs != null;
            if (!rs.next()) break;
            int id = rs.getInt("id");
            String client = rs.getString("name");
            customer.add(client);
        }
        return customer;
    }

    @Transactional(rollbackOn = SQLException.class,
            dontRollbackOn = EntityExistsException.class)
    public List<String> getAllOrders() throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM orders";
        ResultSet rs = stmt.executeQuery(sql);
        List<String> orders = new ArrayList<>();
        while (rs.next()) {
            int id = rs.getInt("id");
            String order = rs.getString("to_addr");
            orders.add(order);
        }
        return orders;
    }

    public int createCustomer(int id,String name, String surname) throws SQLException, ClassNotFoundException {

        String sql = "insert into customer (customer_id,name,surname) values (?,?,?)";
        Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1,id);
        preparedStatement.setString(2,name);
        preparedStatement.setString(3,surname);

        return preparedStatement.executeUpdate();

    }

    public int createOrder(int order_id,int items_id, int customer_id, int cost) throws SQLException, ClassNotFoundException {
        String sql = "insert into orders (order_id,items_id,customer_id,cost) values (?,?,?,?)";
        PreparedStatement preparedStatement;
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS)) {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,order_id);
            preparedStatement.setInt(2,items_id);
            preparedStatement.setInt(3,customer_id);
            preparedStatement.setInt(4,cost);
            return preparedStatement.executeUpdate();
        } catch (Exception $e) {
            $e.printStackTrace();
        }
        return 0;
    }

    @Transactional(rollbackOn = SQLException.class,
            dontRollbackOn = EntityExistsException.class)
    public Response deleteCustomer(int id) throws SQLException, ClassNotFoundException {
        String sql = "delete from customer where id = " + id;
        if (stmt.executeUpdate(sql) == 1) return Response.ok().build();
        return Response.notModified().build();
    }

    public Response updateCustomerName(String name, int id) throws SQLException, ClassNotFoundException {
        try {
            String sql = "UPDATE customer SET name = '" + name + "' WHERE id = " + id;
            if (stmt.executeUpdate(sql) == 1) return Response.ok().build();
            return Response.notModified().build();
        } catch (Exception e) {
            throw new WebApplicationException(Response.status(500, "Error in updating client names").build());
        }
    }



}
